# Changelog

## 1.0.0
- Fondasi: Module/Event/Keybind/Config/GUI Manager, config JSON auto-save.
- ClickGUI dengan background anime, avatar bulat, sidebar, toggle/slider/dropdown, animasi.
- Keybind editor + deteksi konflik + Toggle/Hold + mouse.
- Performance: preset, FPS limiter/VSync, render & simulation distance (+dynamic), entity distance,
  particle limiter, dynamic FPS, memory monitor.
- Visual HUD, Custom Crosshair, Movement helpers, Crystal Macro (pintasan hotbar manual), Settings, About.
- Belum teruji kompilasi/runtime (lihat README).
