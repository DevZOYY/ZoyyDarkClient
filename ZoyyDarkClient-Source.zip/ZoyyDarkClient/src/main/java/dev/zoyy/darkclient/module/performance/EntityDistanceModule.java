package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/** Entity Distance Limiter (opsi Entity Distance bawaan Minecraft). */
public class EntityDistanceModule extends Module {
    public final Setting.Num percent = add(new Setting.Num("Entity Distance %", 50, 500, 10, 100));
    private double old;

    public EntityDistanceModule() { super("Entity Distance", "Batasi jarak render entity", Category.PERFORMANCE); }

    @Override public void onEnable() { old = mc.options.entityDistanceScaling().get(); apply(); }
    @Override public void onDisable() { mc.options.entityDistanceScaling().set(old); }
    @Override public void onTick() { apply(); }

    private void apply() {
        double v = percent.get() / 100.0;
        if (Math.abs(mc.options.entityDistanceScaling().get() - v) > 0.001) mc.options.entityDistanceScaling().set(v);
    }
}
