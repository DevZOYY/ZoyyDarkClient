package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;

/** Keystrokes WASD + Space + LMB/RMB. */
public class KeystrokesModule extends Module {
    public final Setting.Num posX = add(new Setting.Num("Position X %", 0, 100, 1, 2));
    public final Setting.Num posY = add(new Setting.Num("Position Y %", 0, 100, 1, 60));
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 10, 100, 5, 70));
    public final Setting.Mode color = add(new Setting.Mode("Color", 0, Colors.NAMES));

    public KeystrokesModule() { super("Keystrokes", "Tampilkan tombol gerak & klik", Category.VISUAL); }

    private void key(GuiGraphics g, int x, int y, int w, int h, String label, KeyMapping k, int rgb, int a) {
        boolean d = k.isDown();
        g.fill(x, y, x + w, y + h, Colors.argb(d ? rgb : 0x000000, d ? (int) (a * 0.7) : (int) (a * 0.5)));
        int tc = d ? 0xFF000000 : Colors.argb(rgb, Math.max(a, 40));
        g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + (h - 8) / 2, tc);
    }

    @Override public void onHud(GuiGraphics g, float pt) {
        if (mc.player == null) return;
        int W = 3 * 20 + 2, H = 20 * 3 + 2;
        int x = (int) ((g.guiWidth() - W) * posX.get() / 100.0);
        int y = (int) ((g.guiHeight() - H) * posY.get() / 100.0);
        int a = (int) (opacity.get() * 2.55);
        int rgb = Colors.rgb(color.get());
        key(g, x + 21, y, 20, 20, "W", mc.options.keyUp, rgb, a);
        key(g, x, y + 21, 20, 20, "A", mc.options.keyLeft, rgb, a);
        key(g, x + 21, y + 21, 20, 20, "S", mc.options.keyDown, rgb, a);
        key(g, x + 42, y + 21, 20, 20, "D", mc.options.keyRight, rgb, a);
        key(g, x, y + 42, 31, 20, "LMB", mc.options.keyAttack, rgb, a);
        key(g, x + 32, y + 42, 30, 20, "RMB", mc.options.keyUse, rgb, a);
    }
}
