package dev.zoyy.darkclient.core;

import dev.zoyy.darkclient.gui.ClickGuiScreen;
import net.minecraft.client.Minecraft;

public final class GuiManager {
    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new ClickGuiScreen());
    }
    private GuiManager() {}
}
