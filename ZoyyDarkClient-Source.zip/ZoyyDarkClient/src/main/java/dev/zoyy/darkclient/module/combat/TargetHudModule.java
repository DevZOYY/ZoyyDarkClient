package dev.zoyy.darkclient.module.combat;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;
import java.util.Locale;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Target HUD: info makhluk yang sedang dibidik crosshair (ditahan 3 detik). */
public class TargetHudModule extends HudModule {
    private LivingEntity last;
    private long lastSeen;

    public TargetHudModule() { super("Target HUD", "Nama & HP target di crosshair", Category.COMBAT, 50, 62); }

    @Override protected List<String> lines() {
        HitResult hr = mc.hitResult;
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) {
            last = le; lastSeen = System.currentTimeMillis();
        }
        if (last == null || last.isRemoved() || System.currentTimeMillis() - lastSeen > 3000) return null;
        float hp = last.getHealth(), max = last.getMaxHealth();
        double dist = mc.player.distanceTo(last);
        return List.of(last.getName().getString(),
                String.format(Locale.ROOT, "HP %.1f / %.1f", hp, max),
                String.format(Locale.ROOT, "%.1f blocks", dist));
    }
}
