package dev.zoyy.darkclient.module;

import com.google.gson.JsonObject;
import dev.zoyy.darkclient.ZoyyDarkClient;
import dev.zoyy.darkclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Satu fitur = satu class turunan Module. */
public abstract class Module {
    public static final int NO_KEY = -1;

    protected final Minecraft mc = Minecraft.getInstance();
    public final String name, description;
    public final Category category;
    /** true = tombol keybind hanya memicu onTrigger() (bukan on/off). */
    public final boolean actionOnly;

    private boolean enabled;
    public int key = NO_KEY;
    public final int defaultKey;
    public boolean holdMode;
    public boolean keyWasDown;           // dipakai KeybindManager
    public float visualAnim;             // animasi toggle di GUI
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, Category category, boolean actionOnly, int defaultKey) {
        this.name = name; this.description = description; this.category = category;
        this.actionOnly = actionOnly; this.defaultKey = defaultKey; this.key = defaultKey;
    }
    protected Module(String name, String description, Category category) {
        this(name, description, category, false, NO_KEY);
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            ZoyyDarkClient.LOGGER.error("Module {} error saat {}", name, value ? "enable" : "disable", t);
            enabled = false;
        }
    }
    public void toggle() { setEnabled(!enabled); }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(GuiGraphics g, float partialTick) {}
    /** Untuk modul actionOnly. */
    public void onTrigger() {}

    public void resetAll() {
        setEnabled(false);
        key = defaultKey; holdMode = false;
        for (Setting s : settings) s.reset();
    }

    public JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", enabled);
        o.addProperty("key", key);
        o.addProperty("hold", holdMode);
        JsonObject st = new JsonObject();
        for (Setting s : settings) st.add(s.name, s.save());
        o.add("settings", st);
        return o;
    }

    public void load(JsonObject o) {
        try {
            if (o.has("key")) key = o.get("key").getAsInt();
            if (o.has("hold")) holdMode = o.get("hold").getAsBoolean();
            if (o.has("settings")) {
                JsonObject st = o.getAsJsonObject("settings");
                for (Setting s : settings) if (st.has(s.name)) s.load(st.get(s.name));
            }
            if (o.has("enabled") && o.get("enabled").getAsBoolean() && !actionOnly) setEnabled(true);
        } catch (Exception e) {
            ZoyyDarkClient.LOGGER.warn("Gagal memuat config modul {}", name, e);
        }
    }
}
