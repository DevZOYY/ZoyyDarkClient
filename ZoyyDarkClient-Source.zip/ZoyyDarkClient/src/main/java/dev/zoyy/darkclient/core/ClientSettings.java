package dev.zoyy.darkclient.core;

import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import java.util.List;
import org.lwjgl.glfw.GLFW;

/** Pengaturan global client (halaman Settings). */
public final class ClientSettings {
    public static final int DEFAULT_GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;

    public static final Setting.Num animSpeed = new Setting.Num("GUI Animation Speed", 1, 10, 1, 6);
    public static final Setting.Num bgDim = new Setting.Num("Background Opacity (dim %)", 0, 90, 5, 50);
    public static final Setting.Mode theme = new Setting.Mode("Theme", 0, "Dark", "Pitch Black");
    public static final Setting.Mode accent = new Setting.Mode("Accent Color", 1, Colors.NAMES);
    public static final Setting.Bool sounds = new Setting.Bool("Sound Effects", true);

    public static final List<Setting> ALL = List.of(animSpeed, bgDim, theme, accent, sounds);

    public static int guiKey = DEFAULT_GUI_KEY;

    public static int accentRgb() { return Colors.rgb(accent.get()); }
    public static int panelRgb() { return theme.is("Pitch Black") ? 0x000000 : 0x0B0B0B; }
    public static int tileRgb() { return theme.is("Pitch Black") ? 0x0E0E0E : 0x1A1A1A; }

    public static void resetAll() {
        for (Setting s : ALL) s.reset();
        guiKey = DEFAULT_GUI_KEY;
    }
    private ClientSettings() {}
}
