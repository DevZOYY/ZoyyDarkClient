package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;

public class PotionHudModule extends HudModule {
    public PotionHudModule() { super("Potion HUD", "Efek potion aktif + sisa waktu", Category.VISUAL, 100, 50); }
    @Override protected List<String> lines() {
        List<String> out = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            String n = Component.translatable(e.getDescriptionId()).getString();
            String lvl = e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "";
            String time;
            if (e.isInfiniteDuration()) time = "∞";
            else { int s = e.getDuration() / 20; time = (s / 60) + ":" + String.format("%02d", s % 60); }
            out.add(n + lvl + "  " + time);
        }
        return out;
    }
}
