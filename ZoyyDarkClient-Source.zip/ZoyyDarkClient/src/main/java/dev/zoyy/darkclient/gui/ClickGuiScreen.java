package dev.zoyy.darkclient.gui;

import dev.zoyy.darkclient.ZoyyDarkClient;
import dev.zoyy.darkclient.core.ClientSettings;
import dev.zoyy.darkclient.core.ConfigManager;
import dev.zoyy.darkclient.core.KeybindManager;
import dev.zoyy.darkclient.core.ModuleManager;
import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import dev.zoyy.darkclient.util.KeyNames;
import dev.zoyy.darkclient.util.RenderUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

/** ClickGUI ZoyyDarkClient: background anime + overlay gelap, sidebar kategori, toggle/slider/dropdown. */
public class ClickGuiScreen extends Screen {
    private static final Identifier BG = Identifier.fromNamespaceAndPath(ZoyyDarkClient.MOD_ID, "textures/gui/background.png");
    private static final Identifier AVATAR = Identifier.fromNamespaceAndPath(ZoyyDarkClient.MOD_ID, "textures/gui/avatar.png");
    private static final int BG_W = 773, BG_H = 404, AV_SIZE = 256;

    private record Hit(int x, int y, int w, int h, boolean content, IntConsumer action) {}

    // state (static agar halaman terakhir diingat)
    private static Category lastPage = null;            // null = Home
    private Category page = lastPage;
    private Module expanded;
    private Module listenMod;
    private boolean listenGui;
    private Setting.Num dragging;
    private int dragX, dragW;
    private double clickX;

    private float open, scroll, targetScroll;
    private int maxScroll;
    private long lastNs;
    private float dt;
    private String toast = ""; private long toastUntil;
    private long confirmUntil;

    private final List<Hit> hits = new ArrayList<>();
    private int cx, cy, cw, ch;   // area konten

    public ClickGuiScreen() { super(Component.literal("ZoyyDarkClient")); }

    @Override public boolean isPauseScreen() { return false; }
    @Override protected void init() { lastNs = System.nanoTime(); }
    @Override public void removed() { ConfigManager.save(); }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) { /* digambar manual di render() */ }

    // ------------------------------------------------------------------ helpers
    private int al(int a) { return (int) (Math.max(0, Math.min(255, a)) * open); }
    private void box(GuiGraphics g, int x, int y, int w, int h, int r, int rgb, int alpha) {
        RenderUtil.rrect(g, x, y, w, h, r, Colors.argb(rgb, al(alpha)));
    }
    private void txt(GuiGraphics g, String s, int x, int y, int rgb, int alpha) {
        int a = al(alpha);
        if (a < 8) return;                       // alpha < 4 dianggap opaque oleh Font
        g.drawString(this.font, s, x, y, Colors.argb(rgb, a));
    }
    private void ctxt(GuiGraphics g, String s, int cxm, int y, int rgb, int alpha) {
        txt(g, s, cxm - this.font.width(s) / 2, y, rgb, alpha);
    }
    private boolean in(double mx, double my, int x, int y, int w, int h) { return RenderUtil.inside(mx, my, x, y, w, h); }
    private void hit(int x, int y, int w, int h, boolean content, IntConsumer a) { hits.add(new Hit(x, y, w, h, content, a)); }
    private void toast(String s) { toast = s; toastUntil = System.currentTimeMillis() + 2200; }
    private void click() {
        if (ClientSettings.sounds.get())
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    private void button(GuiGraphics g, String label, int x, int y, int w, int h, int mx, int my, boolean content, Runnable r) {
        boolean hov = in(mx, my, x, y, w, h) && (!content || in(mx, my, cx, cy, cw, ch));
        box(g, x, y, w, h, 3, hov ? 0x3A3A3A : 0x252525, 235);
        ctxt(g, label, x + w / 2, y + (h - 8) / 2, 0xFFFFFF, 255);
        hit(x, y, w, h, content, b -> { r.run(); });
    }

    private void drawSwitch(GuiGraphics g, int x, int y, boolean on, float anim) {
        int acc = ClientSettings.accentRgb();
        int bg = on ? acc : 0x3A3A3A;
        box(g, x, y, 26, 12, 6, bg, on ? 230 : 255);
        int kx = x + 2 + Math.round(12 * anim);
        box(g, kx, y + 2, 8, 8, 4, on ? 0x101010 : 0xDDDDDD, 255);
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = System.nanoTime();
        dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        open += (1f - open) * Math.min(1f, dt * ClientSettings.animSpeed.get() * 1.6f);
        if (open > 0.995f) open = 1f;
        scroll += (targetScroll - scroll) * Math.min(1f, dt * 16f);
        hits.clear();

        // ---- background anime (cover) + dim overlay
        float sr = (float) this.width / this.height, tr = (float) BG_W / BG_H;
        int rw, rh, u, v;
        if (tr > sr) { rh = BG_H; rw = Math.round(BG_H * sr); u = (BG_W - rw) / 2; v = 0; }
        else { rw = BG_W; rh = Math.round(BG_W / sr); u = 0; v = (BG_H - rh) / 2; }
        g.blit(RenderPipelines.GUI_TEXTURED, BG, 0, 0, (float) u, (float) v, this.width, this.height, rw, rh, BG_W, BG_H);
        int dim = (int) (ClientSettings.bgDim.get() * 2.55 * open + 255 * (1f - open));
        g.fill(0, 0, this.width, this.height, Colors.argb(0x000000, dim));

        // ---- panel
        int pw = Math.min(560, this.width - 16), ph = Math.min(330, this.height - 16);
        int px = (this.width - pw) / 2, py = (this.height - ph) / 2 + Math.round((1f - open) * 14f);
        int sw = 126;
        box(g, px, py, pw, ph, 8, ClientSettings.panelRgb(), 232);
        box(g, px + sw, py + 10, 1, ph - 20, 0, 0x2A2A2A, 255);

        // ---- header sidebar: avatar bulat + nama
        int avSize = 40;
        g.blit(RenderPipelines.GUI_TEXTURED, AVATAR, px + 10, py + 10, 0f, 0f, avSize, avSize, AV_SIZE, AV_SIZE, AV_SIZE, AV_SIZE);
        txt(g, "ZoyyDarkClient", px + 56, py + 15, 0xFFFFFF, 255);
        txt(g, "ULTIMATE PVP", px + 56, py + 27, 0x8C8C8C, 255);
        txt(g, "DARK EDITION", px + 56, py + 37, 0x5A5A5A, 255);

        // ---- sidebar kategori
        int sy = py + 62;
        sy = sideItem(g, "Home", null, px + 6, sy, sw - 12, mx, my);
        for (Category c : Category.values()) sy = sideItem(g, c.label, c, px + 6, sy, sw - 12, mx, my);

        // ---- header konten
        cx = px + sw + 10; cw = pw - sw - 20;
        txt(g, page == null ? "Home" : page.label, cx, py + 14, 0xFFFFFF, 255);
        box(g, px + pw - 62, py + 10, 52, 16, 8, 0x0F2A14, 255);
        ctxt(g, "ONLINE", px + pw - 36, py + 14, 0x30D060, 255);
        box(g, cx, py + 32, cw, 1, 0, 0x2A2A2A, 255);

        cy = py + 38; ch = ph - 38 - 34;

        // ---- konten (scissor)
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        int used = drawPage(g, mx, my);
        g.disableScissor();
        maxScroll = Math.max(0, used - ch);
        targetScroll = Math.max(0, Math.min(maxScroll, targetScroll));
        if (maxScroll > 0) {                       // scrollbar tipis
            int bh = Math.max(16, ch * ch / used);
            int by = cy + (int) ((ch - bh) * (scroll / maxScroll));
            box(g, cx + cw + 3, by, 2, bh, 1, 0x7A7A7A, 255);
        }

        // ---- footer: Save / Reset
        int fy = py + ph - 28;
        button(g, "Save Configuration", cx, fy, 128, 18, mx, my, false, () -> {
            toast(ConfigManager.save() ? "Konfigurasi tersimpan" : "Gagal menyimpan konfigurasi (lihat log)");
        });
        boolean confirming = System.currentTimeMillis() < confirmUntil;
        button(g, confirming ? "Klik lagi untuk konfirmasi" : "Reset Settings", cx + 134, fy, 150, 18, mx, my, false, this::resetPressed);
        if (System.currentTimeMillis() < toastUntil) ctxt(g, toast, cx + cw - 70, fy + 5, 0xE0E0E0, 255);

        // ---- slider drag (polling mouse)
        if (dragging != null) {
            long win = this.minecraft.getWindow().handle();
            if (GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) setSlider(mx);
            else dragging = null;
        }
    }

    private void setSlider(double mx) {
        double f = Math.max(0, Math.min(1, (mx - dragX) / (double) dragW));
        dragging.set(dragging.min + f * (dragging.max - dragging.min));
        dragging.onChange.run();
    }

    private int sideItem(GuiGraphics g, String label, Category c, int x, int y, int w, int mx, int my) {
        boolean sel = page == c;
        boolean hov = in(mx, my, x, y, w, 18);
        if (sel) box(g, x, y, w, 18, 4, ClientSettings.tileRgb(), 255);
        else if (hov) box(g, x, y, w, 18, 4, 0x151515, 255);
        if (sel) box(g, x, y + 4, 2, 10, 1, ClientSettings.accentRgb(), 255);
        txt(g, label, x + 10, y + 5, sel ? 0xFFFFFF : 0x9A9A9A, 255);
        hit(x, y, w, 18, false, b -> { page = c; lastPage = c; expanded = null; targetScroll = 0; scroll = 0; click(); });
        return y + 20;
    }

    private void resetPressed() {
        long now = System.currentTimeMillis();
        if (now > confirmUntil) { confirmUntil = now + 3000; return; }
        confirmUntil = 0;
        if (page != null && page != Category.SETTINGS && page != Category.ABOUT) {
            for (Module m : ModuleManager.of(page)) m.resetAll();
            toast("Pengaturan " + page.label + " di-reset");
        } else {
            ModuleManager.resetAll();
            toast("Semua pengaturan di-reset");
        }
        ConfigManager.save();
    }

    // ------------------------------------------------------------------ pages
    private int drawPage(GuiGraphics g, int mx, int my) {
        int y = cy - Math.round(scroll);
        if (page == null) return drawHome(g, mx, my, y) ;
        if (page == Category.ABOUT) return drawAbout(g, y);
        if (page == Category.SETTINGS) return drawSettings(g, mx, my, y);
        int start = y;
        for (Module m : ModuleManager.of(page)) y += drawModule(g, m, cx, y, cw, mx, my);
        return y - start;
    }

    private int drawHome(GuiGraphics g, int mx, int my, int y0) {
        Category[] tiles = {Category.PERFORMANCE, Category.COMBAT, Category.VISUAL, Category.MOVEMENT, Category.CRYSTAL, Category.SETTINGS};
        int gap = 8, tw = (cw - gap) / 2, th = Math.min(52, (ch - gap * 2) / 3);
        for (int i = 0; i < tiles.length; i++) {
            int tx = cx + (i % 2) * (tw + gap), ty = y0 + (i / 2) * (th + gap);
            Category c = tiles[i];
            boolean hov = in(mx, my, tx, ty, tw, th) && in(mx, my, cx, cy, cw, ch);
            box(g, tx, ty, tw, th, 6, hov ? 0x242424 : ClientSettings.tileRgb(), 235);
            box(g, tx + 10, ty + 10, 14, 2, 1, ClientSettings.accentRgb(), 255);
            txt(g, c.label, tx + 10, ty + th - 22, 0xFFFFFF, 255);
            int n = ModuleManager.of(c).size();
            txt(g, c == Category.SETTINGS ? "Keybind, config, tema" : n + " fitur", tx + 10, ty + th - 12, 0x7A7A7A, 255);
            hit(tx, ty, tw, th, true, b -> { page = c; lastPage = c; targetScroll = 0; scroll = 0; click(); });
        }
        txt(g, "ZOYY DARK CLIENT • DARK EDITION", cx, y0 + 3 * (th + gap) + 2, 0x6A6A6A, 255);
        return 3 * (th + gap) + 14;
    }

    private int drawAbout(GuiGraphics g, int y0) {
        String loader = FabricLoader.getInstance().getModContainer("fabricloader")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
        Runtime r = Runtime.getRuntime();
        long max = r.maxMemory() / 1048576L, used = (r.totalMemory() - r.freeMemory()) / 1048576L;
        String[][] rows = {
                {"Client", ZoyyDarkClient.NAME},
                {"Client Version", ZoyyDarkClient.VERSION},
                {"Minecraft Version", ZoyyDarkClient.MC_VERSION},
                {"Mod Loader", "Fabric " + loader},
                {"Developer", "Zoyy Team"},
                {"FPS", String.valueOf(this.minecraft.getFps())},
                {"Memory", used + " / " + max + " MB"},
                {"Client Status", "ONLINE"},
                {"Config", ConfigManager.configFile().getFileName().toString()},
        };
        int y = y0;
        for (String[] row : rows) {
            box(g, cx, y, cw, 20, 3, ClientSettings.tileRgb(), 210);
            txt(g, row[0], cx + 10, y + 6, 0x8C8C8C, 255);
            txt(g, row[1], cx + 130, y + 6, row[0].equals("Client Status") ? 0x30D060 : 0xFFFFFF, 255);
            y += 22;
        }
        return y - y0;
    }

    private int drawSettings(GuiGraphics g, int mx, int my, int y0) {
        int y = y0;
        txt(g, "Tampilan", cx, y + 2, 0x8C8C8C, 255); y += 14;
        for (Setting s : ClientSettings.ALL) y += settingRow(g, s, cx, y, cw, mx, my) + 1;
        y += 6;
        txt(g, "Keybind Manager", cx, y + 2, 0x8C8C8C, 255); y += 14;
        y += keyRow(g, "ClickGUI", ClientSettings.guiKey, listenGui, cx, y, cw, mx, my,
                () -> { listenGui = true; listenMod = null; },
                () -> { String c = KeybindManager.bindGui(ClientSettings.DEFAULT_GUI_KEY); toast(c == null ? "ClickGUI: default" : "Bentrok dengan " + c); }) + 1;
        for (Module m : ModuleManager.all()) {
            y += keyRow(g, m.name, m.key, listenMod == m, cx, y, cw, mx, my,
                    () -> { listenMod = m; listenGui = false; },
                    () -> { String c = KeybindManager.bind(m, m.defaultKey); toast(c == null ? m.name + ": default" : "Bentrok dengan " + c); }) + 1;
        }
        y += 6;
        int bw = (cw - 12) / 3;
        button(g, "Reset Default Keybind", cx, y, bw, 18, mx, my, true, this::resetKeybinds);
        button(g, "Export Config", cx + bw + 6, y, bw, 18, mx, my, true,
                () -> toast(ConfigManager.export() ? "Diexport: zoyydarkclient-export.json" : "Export gagal"));
        button(g, "Import Config", cx + 2 * (bw + 6), y, bw, 18, mx, my, true,
                () -> toast(ConfigManager.importConfig() ? "Config diimport" : "File export tidak ditemukan"));
        y += 24;
        txt(g, "Export/Import: folder config Minecraft", cx, y, 0x5A5A5A, 255); y += 12;
        return y - y0;
    }

    private void resetKeybinds() {
        ClientSettings.guiKey = ClientSettings.DEFAULT_GUI_KEY;
        for (Module m : ModuleManager.all()) m.key = m.defaultKey;
        toast("Semua keybind dikembalikan ke default");
    }

    // ------------------------------------------------------------------ rows
    private int drawModule(GuiGraphics g, Module m, int x, int y, int w, int mx, int my) {
        int h = 26;
        boolean inContent = in(mx, my, cx, cy, cw, ch);
        boolean hov = inContent && in(mx, my, x, y, w, h);
        m.visualAnim += ((m.isEnabled() ? 1f : 0f) - m.visualAnim) * Math.min(1f, dt * 14f);
        box(g, x, y, w, h, 4, hov ? 0x232323 : ClientSettings.tileRgb(), 225);
        if (m.isEnabled()) box(g, x, y + 5, 2, h - 10, 1, ClientSettings.accentRgb(), 255);
        txt(g, m.name, x + 9, y + 5, 0xFFFFFF, 255);
        String desc = this.font.plainSubstrByWidth(m.description, Math.max(40, w - 150));
        txt(g, desc, x + 9, y + 15, 0x7A7A7A, 255);

        hit(x, y, w, h, true, b -> { expanded = expanded == m ? null : m; click(); });

        int rx = x + w - 10;
        if (m.actionOnly) {
            button(g, "RUN", rx - 34, y + 5, 34, 16, mx, my, true, m::onTrigger);
            rx -= 40;
        } else {
            drawSwitch(g, rx - 26, y + 7, m.isEnabled(), m.visualAnim);
            hit(rx - 28, y + 4, 30, 18, true, b -> { m.toggle(); click(); });
            rx -= 34;
        }
        if (m.key >= 0) {
            String k = "[" + KeyNames.of(m.key) + (m.holdMode && !m.actionOnly ? " / hold" : "") + "]";
            txt(g, k, rx - this.font.width(k), y + 9, 0x8C8C8C, 255);
        }

        int used = h + 2;
        if (expanded == m) {
            for (Setting s : m.settings) used += settingRow(g, s, x, y + used, w, mx, my) + 1;
            used += keyRow(g, "Keybind", m.key, listenMod == m, x, y + used, w, mx, my,
                    () -> { listenMod = m; listenGui = false; },
                    () -> { String c = KeybindManager.bind(m, m.defaultKey); toast(c == null ? "Keybind: default" : "Bentrok dengan " + c); }) + 1;
            if (!m.actionOnly) {
                used += holdRow(g, m, x, y + used, w, mx, my) + 1;
            }
            used += 3;
        }
        return used;
    }

    private int holdRow(GuiGraphics g, Module m, int x, int y, int w, int mx, int my) {
        box(g, x + 6, y, w - 6, 19, 3, 0x121212, 210);
        txt(g, "Hold Mode (aktif selama tombol ditahan)", x + 14, y + 6, 0xC8C8C8, 255);
        int rx = x + w - 8;
        drawSwitch(g, rx - 26, y + 4, m.holdMode, m.holdMode ? 1f : 0f);
        hit(rx - 28, y + 2, 30, 16, true, b -> { m.holdMode = !m.holdMode; click(); });
        return 20;
    }

    private int keyRow(GuiGraphics g, String label, int key, boolean listening, int x, int y, int w, int mx, int my,
                       Runnable startListen, Runnable reset) {
        box(g, x + 6, y, w - 6, 19, 3, 0x121212, 210);
        txt(g, label, x + 14, y + 6, 0xC8C8C8, 255);
        int rx = x + w - 8;
        // tombol reset default
        button(g, "R", rx - 16, y + 2, 16, 15, mx, my, true, reset);
        int bw = 104, bx = rx - 16 - 6 - bw;
        boolean hov = in(mx, my, bx, y + 2, bw, 15) && in(mx, my, cx, cy, cw, ch);
        box(g, bx, y + 2, bw, 15, 3, listening ? ClientSettings.accentRgb() : (hov ? 0x3A3A3A : 0x262626), listening ? 200 : 255);
        ctxt(g, listening ? "Tekan tombol..." : KeyNames.of(key), bx + bw / 2, y + 6, listening ? 0x000000 : 0xFFFFFF, 255);
        hit(bx, y + 2, bw, 15, true, b -> { startListen.run(); click(); });
        return 20;
    }

    private int settingRow(GuiGraphics g, Setting s, int x, int y, int w, int mx, int my) {
        int h = 19;
        box(g, x + 6, y, w - 6, h, 3, 0x121212, 210);
        txt(g, s.name, x + 14, y + 6, 0xC8C8C8, 255);
        int rx = x + w - 8;
        if (s instanceof Setting.Bool b) {
            drawSwitch(g, rx - 26, y + 4, b.get(), b.get() ? 1f : 0f);
            hit(rx - 28, y + 2, 30, 16, true, btn -> { b.toggle(); click(); });
        } else if (s instanceof Setting.Num n) {
            int tw = 110, tx = x + w - 8 - 44 - tw;
            box(g, tx, y + 8, tw, 3, 1, 0x353535, 255);
            int fw = (int) (tw * n.fraction());
            box(g, tx, y + 8, Math.max(1, fw), 3, 1, ClientSettings.accentRgb(), 255);
            box(g, tx + fw - 2, y + 4, 5, 11, 2, 0xEEEEEE, 255);
            txt(g, n.display(), tx + tw + 8, y + 6, 0xFFFFFF, 255);
            hit(tx - 4, y + 2, tw + 8, 16, true, btn -> {
                dragging = n; dragX = tx; dragW = tw; setSlider(clickX);
            });
        } else if (s instanceof Setting.Mode m) {
            int bw = 118, bx = rx - bw;
            boolean hov = in(mx, my, bx, y + 2, bw, 15) && in(mx, my, cx, cy, cw, ch);
            box(g, bx, y + 2, bw, 15, 3, hov ? 0x3A3A3A : 0x262626, 255);
            ctxt(g, "< " + m.get() + " >", bx + bw / 2, y + 6, 0xFFFFFF, 255);
            hit(bx, y + 2, bw, 15, true, btn -> { m.cycle(btn == 1 ? -1 : 1); click(); });
        }
        return h;
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int button = event.button();
        clickX = mx;
        if (listenMod != null || listenGui) {                     // bind tombol mouse
            applyBind(KeyNames.MOUSE_BASE + button);
            return true;
        }
        boolean inContent = in(mx, my, cx, cy, cw, ch);
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.content && !inContent) continue;
            h.action.accept(button);
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listenMod != null || listenGui) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { listenMod = null; listenGui = false; return true; }
            if ((key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) && listenMod != null) {
                listenMod.key = Module.NO_KEY; listenMod = null; toast("Keybind dihapus"); return true;
            }
            applyBind(key);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == ClientSettings.guiKey) { this.onClose(); return true; }
        return super.keyPressed(event);
    }

    private void applyBind(int code) {
        String conflict;
        if (listenGui) conflict = KeybindManager.bindGui(code);
        else conflict = KeybindManager.bind(listenMod, code);
        if (conflict != null) toast("Bentrok dengan: " + conflict);
        else toast("Keybind: " + KeyNames.of(code));
        listenMod = null; listenGui = false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        targetScroll = Math.max(0, Math.min(maxScroll, targetScroll - (float) sy * 26f));
        return true;
    }
}
