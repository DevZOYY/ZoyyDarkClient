package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;

public class DirectionModule extends HudModule {
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    public DirectionModule() { super("Direction HUD", "Arah hadap (N/E/S/W)", Category.VISUAL, 50, 0); }
    @Override protected List<String> lines() {
        double yaw = mc.player.getYRot();
        double angle = ((yaw + 180.0) % 360.0 + 360.0) % 360.0;   // 0 = utara
        int idx = ((int) Math.round(angle / 45.0)) % 8;
        return List.of(DIRS[idx] + "  (" + Math.round(angle) + "°)");
    }
}
