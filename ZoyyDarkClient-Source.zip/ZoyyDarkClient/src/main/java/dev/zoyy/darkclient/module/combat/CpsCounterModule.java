package dev.zoyy.darkclient.module.combat;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

/** CPS Counter: menghitung klik kiri/kanan pemain sendiri (hanya tampilan). */
public class CpsCounterModule extends HudModule {
    private final Deque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private boolean ld, rd;

    public CpsCounterModule() { super("CPS Counter", "Tampilkan klik per detik", Category.COMBAT, 0, 12); }

    @Override protected List<String> lines() {
        long now = System.currentTimeMillis();
        boolean l = mc.options.keyAttack.isDown(), r = mc.options.keyUse.isDown();
        if (l && !ld) left.addLast(now);
        if (r && !rd) right.addLast(now);
        ld = l; rd = r;
        while (!left.isEmpty() && now - left.peekFirst() > 1000) left.pollFirst();
        while (!right.isEmpty() && now - right.peekFirst() > 1000) right.pollFirst();
        return List.of("CPS: " + left.size() + " | " + right.size());
    }
}
