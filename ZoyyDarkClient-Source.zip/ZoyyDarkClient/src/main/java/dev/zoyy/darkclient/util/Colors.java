package dev.zoyy.darkclient.util;

public final class Colors {
    public static final String[] NAMES = {"White", "Silver", "Red", "Crimson", "Purple", "Cyan", "Green", "Yellow"};
    public static final int[] VALUES = {0xFFFFFF, 0xC8C8C8, 0xFF4444, 0xDC143C, 0xA070FF, 0x40E0F0, 0x30D060, 0xFFE040};

    public static int rgb(String name) {
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equalsIgnoreCase(name)) return VALUES[i];
        return 0xFFFFFF;
    }
    /** Gabungkan warna RGB dengan alpha 0..255. */
    public static int argb(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0xFFFFFF);
    }
    public static int mulAlpha(int argb, float a) {
        int al = (int) (((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }
    private Colors() {}
}
