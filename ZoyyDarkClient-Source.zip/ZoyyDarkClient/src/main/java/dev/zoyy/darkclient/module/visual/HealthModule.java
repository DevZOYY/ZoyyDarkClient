package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;
import java.util.Locale;

public class HealthModule extends HudModule {
    public HealthModule() { super("Health Display", "Tampilkan HP angka", Category.VISUAL, 50, 88); }
    @Override protected List<String> lines() {
        float abs = mc.player.getAbsorptionAmount();
        String extra = abs > 0 ? String.format(Locale.ROOT, " (+%.1f)", abs) : "";
        return List.of(String.format(Locale.ROOT, "HP: %.1f / %.1f", mc.player.getHealth(), mc.player.getMaxHealth()) + extra);
    }
}
