package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;
import java.util.Locale;

public class CoordinatesModule extends HudModule {
    public CoordinatesModule() { super("Coordinates HUD", "Tampilkan koordinat XYZ", Category.VISUAL, 0, 6); }
    @Override protected List<String> lines() {
        return List.of(String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ()));
    }
}
