package dev.zoyy.darkclient.module.crystal;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * Pintasan hotbar MANUAL: satu tombol memilih slot hotbar yang berisi item tertentu
 * (sama seperti menekan angka 1-9 sendiri). Tidak menempatkan blok/crystal otomatis
 * dan tidak menyerang.
 */
public class QuickSwapModule extends Module {
    private final Item item;
    public final Setting.Bool swapBack = add(new Setting.Bool("Tekan lagi = kembali ke slot sebelumnya", true));
    private int previous = -1;

    public QuickSwapModule(String name, String desc, int itemId, int defaultKey) {
        super(name, desc, Category.CRYSTAL, true, defaultKey);
        this.item = switch (itemId) {
            case 0 -> Items.END_CRYSTAL;
            case 1 -> Items.OBSIDIAN;
            case 2 -> Items.ENDER_PEARL;
            default -> Items.TOTEM_OF_UNDYING;
        };
    }

    @Override public void onTrigger() {
        if (mc.player == null) return;
        Inventory inv = mc.player.getInventory();
        int cur = inv.getSelectedSlot();
        if (inv.getItem(cur).getItem() == item) {
            if (swapBack.get() && previous >= 0 && previous != cur) inv.setSelectedSlot(previous);
            return;
        }
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).getItem() == item) {
                previous = cur;
                inv.setSelectedSlot(i);
                return;
            }
        }
    }
}
