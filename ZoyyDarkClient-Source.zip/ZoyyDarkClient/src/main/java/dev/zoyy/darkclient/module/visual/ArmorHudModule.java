package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Armor HUD: ikon armor + sisa durability. */
public class ArmorHudModule extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public final Setting.Num posX = add(new Setting.Num("Position X %", 0, 100, 1, 98));
    public final Setting.Num posY = add(new Setting.Num("Position Y %", 0, 100, 1, 70));
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 10, 100, 5, 100));
    public final Setting.Mode color = add(new Setting.Mode("Text Color", 0, Colors.NAMES));
    public final Setting.Bool showDurability = add(new Setting.Bool("Show Durability", true));

    public ArmorHudModule() { super("Armor HUD", "Tampilkan armor yang dipakai", Category.VISUAL); }

    @Override public void onHud(GuiGraphics g, float pt) {
        if (mc.player == null) return;
        int w = showDurability.get() ? 52 : 18, h = 4 * 18;
        int x = (int) ((g.guiWidth() - w) * posX.get() / 100.0);
        int y = (int) ((g.guiHeight() - h) * posY.get() / 100.0);
        int a = (int) (opacity.get() * 2.55);
        int rgb = Colors.rgb(color.get());
        for (int i = 0; i < 4; i++) {
            ItemStack s = mc.player.getItemBySlot(SLOTS[i]);
            if (s.isEmpty()) continue;
            int yy = y + i * 18;
            g.fill(x - 1, yy - 1, x + w, yy + 17, Colors.argb(0x000000, (int) (a * 0.4)));
            g.renderItem(s, x, yy);
            if (showDurability.get() && s.isDamageableItem()) {
                int left = s.getMaxDamage() - s.getDamageValue();
                int pct = left * 100 / Math.max(1, s.getMaxDamage());
                g.drawString(mc.font, pct + "%", x + 20, yy + 4, Colors.argb(rgb, Math.max(a, 26)));
            }
        }
    }
}
