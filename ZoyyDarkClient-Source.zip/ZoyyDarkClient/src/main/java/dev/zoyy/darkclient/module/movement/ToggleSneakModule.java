package dev.zoyy.darkclient.module.movement;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;

/** Sneak tetap aktif sampai modul dimatikan (toggle lewat keybind modul). */
public class ToggleSneakModule extends Module {
    public ToggleSneakModule() { super("Toggle Sneak", "Sneak tetap aktif tanpa menahan tombol", Category.MOVEMENT); }

    @Override public void onTick() {
        if (mc.player != null && mc.screen == null) mc.options.keyShift.setDown(true);
    }
    @Override public void onDisable() { mc.options.keyShift.setDown(false); }
}
