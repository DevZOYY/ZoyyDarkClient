package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/** Custom FPS limiter + VSync toggle lewat opsi resmi Minecraft. */
public class FpsLimiterModule extends Module {
    public final Setting.Num limit = add(new Setting.Num("FPS Limit (260 = unlimited)", 30, 260, 10, 144));
    public final Setting.Bool vsync = add(new Setting.Bool("VSync", false));
    private int oldLimit; private boolean oldVsync;

    public FpsLimiterModule() { super("FPS Limiter", "Batasi FPS dan atur VSync", Category.PERFORMANCE); }

    @Override public void onEnable() {
        oldLimit = mc.options.framerateLimit().get();
        oldVsync = mc.options.enableVsync().get();
        apply();
    }
    @Override public void onDisable() {
        mc.options.framerateLimit().set(oldLimit);
        mc.options.enableVsync().set(oldVsync);
    }
    @Override public void onTick() { apply(); }

    private void apply() {
        if (!mc.options.framerateLimit().get().equals(limit.getInt())) mc.options.framerateLimit().set(limit.getInt());
        if (mc.options.enableVsync().get() != vsync.get()) mc.options.enableVsync().set(vsync.get());
    }
}
