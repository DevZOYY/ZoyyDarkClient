package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;

public class FpsCounterModule extends HudModule {
    public FpsCounterModule() { super("FPS Counter", "Tampilkan FPS asli", Category.VISUAL, 0, 0); }
    @Override protected List<String> lines() { return List.of("FPS: " + mc.getFps()); }
}
