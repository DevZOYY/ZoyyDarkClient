package dev.zoyy.darkclient.core;

import com.google.gson.*;
import dev.zoyy.darkclient.ZoyyDarkClient;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import net.fabricmc.loader.api.FabricLoader;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path dir() { return FabricLoader.getInstance().getConfigDir(); }
    public static Path configFile() { return dir().resolve("zoyydarkclient.json"); }
    public static Path exportFile() { return dir().resolve("zoyydarkclient-export.json"); }

    private static JsonObject toJson() {
        JsonObject root = new JsonObject();
        root.addProperty("version", ZoyyDarkClient.VERSION);
        JsonObject gui = new JsonObject();
        gui.addProperty("guiKey", ClientSettings.guiKey);
        for (Setting s : ClientSettings.ALL) gui.add(s.name, s.save());
        root.add("client", gui);
        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.all()) mods.add(m.name, m.save());
        root.add("modules", mods);
        return root;
    }

    private static void fromJson(JsonObject root) {
        if (root.has("client")) {
            JsonObject gui = root.getAsJsonObject("client");
            if (gui.has("guiKey")) ClientSettings.guiKey = gui.get("guiKey").getAsInt();
            for (Setting s : ClientSettings.ALL) if (gui.has(s.name)) s.load(gui.get(s.name));
        }
        if (root.has("modules")) {
            JsonObject mods = root.getAsJsonObject("modules");
            for (Module m : ModuleManager.all()) if (mods.has(m.name)) m.load(mods.getAsJsonObject(m.name));
        }
    }

    private static boolean write(Path target) {
        try {
            Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(toJson()), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException | RuntimeException e) {
            ZoyyDarkClient.LOGGER.error("Gagal menyimpan {}", target, e);
            return false;
        }
    }

    private static boolean read(Path source) {
        try {
            if (!Files.exists(source)) return false;
            String text = Files.readString(source, StandardCharsets.UTF_8);
            fromJson(JsonParser.parseString(text).getAsJsonObject());
            return true;
        } catch (IOException | RuntimeException e) {
            ZoyyDarkClient.LOGGER.error("Gagal membaca {}", source, e);
            return false;
        }
    }

    public static boolean save() { return write(configFile()); }
    public static boolean load() { return read(configFile()); }
    public static boolean export() { return write(exportFile()); }
    public static boolean importConfig() { return read(exportFile()); }
    private ConfigManager() {}
}
