package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/** Menurunkan FPS saat jendela Minecraft tidak fokus (hemat CPU/GPU). */
public class DynamicFpsModule extends Module {
    public final Setting.Num idleFps = add(new Setting.Num("FPS saat tidak fokus", 5, 60, 5, 15));
    private boolean applied;
    private int saved;

    public DynamicFpsModule() { super("Dynamic FPS", "Kurangi FPS ketika game tidak fokus", Category.PERFORMANCE); }

    @Override public void onDisable() { restore(); }
    @Override public void onTick() {
        if (!mc.isWindowActive()) {
            if (!applied) { saved = mc.options.framerateLimit().get(); applied = true; }
            if (mc.options.framerateLimit().get() != idleFps.getInt()) mc.options.framerateLimit().set(idleFps.getInt());
        } else restore();
    }
    private void restore() {
        if (applied) { mc.options.framerateLimit().set(saved); applied = false; }
    }
}
