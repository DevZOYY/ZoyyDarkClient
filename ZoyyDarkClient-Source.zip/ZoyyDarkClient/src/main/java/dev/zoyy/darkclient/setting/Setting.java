package dev.zoyy.darkclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

/** Basis semua pengaturan (bool / angka / pilihan). */
public abstract class Setting {
    public final String name;
    /** Dipanggil setiap nilai berubah lewat GUI. */
    public Runnable onChange = () -> {};

    protected Setting(String name) { this.name = name; }

    public abstract JsonElement save();
    public abstract void load(JsonElement e);
    public abstract void reset();

    public static final class Bool extends Setting {
        private final boolean def;
        private boolean value;
        public Bool(String name, boolean def) { super(name); this.def = def; this.value = def; }
        public boolean get() { return value; }
        public void set(boolean v) { value = v; }
        public void toggle() { value = !value; onChange.run(); }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { try { value = e.getAsBoolean(); } catch (Exception ignored) {} }
        @Override public void reset() { value = def; }
    }

    public static final class Num extends Setting {
        public final double min, max, step, def;
        private double value;
        public Num(String name, double min, double max, double step, double def) {
            super(name); this.min = min; this.max = max; this.step = step; this.def = def; this.value = def;
        }
        public double get() { return value; }
        public int getInt() { return (int) Math.round(value); }
        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
        public double fraction() { return (value - min) / (max - min); }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { try { set(e.getAsDouble()); } catch (Exception ignored) {} }
        @Override public void reset() { value = def; }
        public String display() {
            return step >= 1 ? String.valueOf(getInt()) : String.format(java.util.Locale.ROOT, "%.2f", value);
        }
    }

    public static final class Mode extends Setting {
        public final List<String> modes;
        private final int def;
        private int index;
        public Mode(String name, int def, String... modes) {
            super(name); this.modes = List.of(modes); this.def = def; this.index = def;
        }
        public String get() { return modes.get(index); }
        public int index() { return index; }
        public boolean is(String m) { return get().equalsIgnoreCase(m); }
        public void set(int i) { index = Math.floorMod(i, modes.size()); }
        public void cycle(int dir) { set(index + dir); onChange.run(); }
        @Override public JsonElement save() { return new JsonPrimitive(get()); }
        @Override public void load(JsonElement e) {
            try { int i = modes.indexOf(e.getAsString()); if (i >= 0) index = i; } catch (Exception ignored) {}
        }
        @Override public void reset() { index = def; }
    }
}
