package dev.zoyy.darkclient.module.movement;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import dev.zoyy.darkclient.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Movement HUD: kecepatan (blok/detik) + statistik jarak & kecepatan tertinggi. */
public class MovementHudModule extends HudModule {
    public final Setting.Bool stats = add(new Setting.Bool("Show Statistics", true));
    private double px, pz; private boolean has;
    private double speed, maxSpeed, distance;

    public MovementHudModule() { super("Movement HUD", "Kecepatan & statistik gerak", Category.MOVEMENT, 0, 30); }

    @Override public void onEnable() { has = false; maxSpeed = 0; distance = 0; }

    @Override public void onTick() {
        if (mc.player == null) { has = false; return; }
        double x = mc.player.getX(), z = mc.player.getZ();
        if (has) {
            double d = Math.hypot(x - px, z - pz);
            if (d < 20) {                      // abaikan teleport
                speed = d * 20.0; distance += d;
                maxSpeed = Math.max(maxSpeed, speed);
            }
        }
        px = x; pz = z; has = true;
    }

    @Override protected List<String> lines() {
        List<String> l = new ArrayList<>();
        l.add(String.format(Locale.ROOT, "Speed: %.2f b/s", speed));
        if (stats.get()) {
            l.add(String.format(Locale.ROOT, "Max: %.2f b/s", maxSpeed));
            l.add(String.format(Locale.ROOT, "Dist: %.1f blocks", distance));
        }
        return l;
    }
}
