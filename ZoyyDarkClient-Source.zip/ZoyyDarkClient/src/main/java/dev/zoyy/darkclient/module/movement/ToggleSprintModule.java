package dev.zoyy.darkclient.module.movement;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;

/** Sprint otomatis saat berjalan maju (tanpa menahan tombol sprint). */
public class ToggleSprintModule extends Module {
    public ToggleSprintModule() { super("Toggle Sprint", "Sprint otomatis saat maju", Category.MOVEMENT); }

    @Override public void onTick() {
        if (mc.player == null || mc.screen != null) return;
        if (mc.options.keyUp.isDown() && !mc.options.keyShift.isDown() && !mc.player.isUsingItem()) {
            mc.options.keySprint.setDown(true);
        }
    }
    @Override public void onDisable() { mc.options.keySprint.setDown(false); }
}
