package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/** Render Distance Limiter + Simulation Distance + Dynamic Render Distance. */
public class RenderDistanceModule extends Module {
    public final Setting.Num render = add(new Setting.Num("Render Distance", 2, 32, 1, 10));
    public final Setting.Num simulation = add(new Setting.Num("Simulation Distance", 5, 32, 1, 8));
    public final Setting.Bool dynamic = add(new Setting.Bool("Dynamic Render Distance", false));
    public final Setting.Num targetFps = add(new Setting.Num("Dynamic: Target FPS", 30, 240, 10, 90));
    public final Setting.Num dynMin = add(new Setting.Num("Dynamic: Min Distance", 2, 16, 1, 4));
    private int oldRender, oldSim, current, timer;

    public RenderDistanceModule() { super("Render Distance", "Batasi jarak render/simulasi, opsional dinamis", Category.PERFORMANCE); }

    @Override public void onEnable() {
        oldRender = mc.options.renderDistance().get();
        oldSim = mc.options.simulationDistance().get();
        current = render.getInt();
        apply(current);
        mc.options.simulationDistance().set(simulation.getInt());
    }
    @Override public void onDisable() {
        mc.options.renderDistance().set(oldRender);
        mc.options.simulationDistance().set(oldSim);
    }

    private void apply(int d) {
        if (mc.options.renderDistance().get() != d) mc.options.renderDistance().set(d);
    }

    @Override public void onTick() {
        if (mc.options.simulationDistance().get() != simulation.getInt()) mc.options.simulationDistance().set(simulation.getInt());
        int max = render.getInt();
        if (!dynamic.get()) { current = max; apply(current); timer = 0; return; }
        // Cek tiap 10 detik supaya chunk tidak reload terus-menerus.
        if (++timer < 200) return;
        timer = 0;
        int fps = mc.getFps();
        int min = Math.min(dynMin.getInt(), max);
        if (fps < targetFps.get() * 0.85 && current > min) current--;
        else if (fps > targetFps.get() * 1.4 && current < max) current++;
        current = Math.max(min, Math.min(max, current));
        apply(current);
    }
}
