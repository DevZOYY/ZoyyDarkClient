package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/** Particle Limiter (opsi Particles bawaan Minecraft). Tidak meng-import enum agar kebal perubahan package. */
public class ParticleLimiterModule extends Module {
    public final Setting.Mode level = add(new Setting.Mode("Particles", 1, "All", "Decreased", "Minimal"));
    private String oldName;

    public ParticleLimiterModule() { super("Particle Limiter", "Kurangi partikel saat pertarungan ramai", Category.PERFORMANCE); }

    @Override public void onEnable() { oldName = mc.options.particles().get().name(); apply(oldName); }
    @Override public void onDisable() { if (oldName != null) apply(oldName); }
    @Override public void onTick() { apply(level.get().toUpperCase()); }

    private void apply(String name) {
        var opt = mc.options.particles();
        if (opt.get().name().equals(name)) return;
        for (var c : opt.get().getDeclaringClass().getEnumConstants()) {
            if (c.name().equals(name)) { opt.set(c); return; }
        }
    }
}
