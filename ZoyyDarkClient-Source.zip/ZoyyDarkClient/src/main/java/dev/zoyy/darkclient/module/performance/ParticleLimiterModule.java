package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import net.minecraft.client.ParticleStatus;

/** Particle Limiter (opsi Particles bawaan Minecraft). */
public class ParticleLimiterModule extends Module {
    public final Setting.Mode level = add(new Setting.Mode("Particles", 1, "All", "Decreased", "Minimal"));
    private ParticleStatus old;

    public ParticleLimiterModule() { super("Particle Limiter", "Kurangi partikel saat pertarungan ramai", Category.PERFORMANCE); }

    @Override public void onEnable() { old = mc.options.particles().get(); apply(); }
    @Override public void onDisable() { if (old != null) mc.options.particles().set(old); }
    @Override public void onTick() { apply(); }

    private void apply() {
        ParticleStatus s = switch (level.get()) {
            case "All" -> ParticleStatus.ALL;
            case "Decreased" -> ParticleStatus.DECREASED;
            default -> ParticleStatus.MINIMAL;
        };
        if (mc.options.particles().get() != s) mc.options.particles().set(s);
    }
}
