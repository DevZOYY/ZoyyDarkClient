package dev.zoyy.darkclient.module;

public enum Category {
    PERFORMANCE("Performance"), COMBAT("Combat"), VISUAL("Visual"),
    MOVEMENT("Movement"), CRYSTAL("Crystal Macro"), SETTINGS("Settings"), ABOUT("About");

    public final String label;
    Category(String label) { this.label = label; }
}
