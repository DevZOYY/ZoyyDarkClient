package dev.zoyy.darkclient.core;

import dev.zoyy.darkclient.ZoyyDarkClient;
import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.module.combat.*;
import dev.zoyy.darkclient.module.crystal.QuickSwapModule;
import dev.zoyy.darkclient.module.movement.*;
import dev.zoyy.darkclient.module.performance.*;
import dev.zoyy.darkclient.module.visual.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.clear();
        // PERFORMANCE
        add(new PerformancePresetModule());
        add(new FpsLimiterModule());
        add(new RenderDistanceModule());
        add(new EntityDistanceModule());
        add(new ParticleLimiterModule());
        add(new DynamicFpsModule());
        add(new MemoryMonitorModule());
        // COMBAT (hanya HUD/informasi)
        add(new CpsCounterModule());
        add(new TargetHudModule());
        add(new ItemCounterModule());
        // VISUAL
        add(new FpsCounterModule());
        add(new CoordinatesModule());
        add(new PingModule());
        add(new DirectionModule());
        add(new HealthModule());
        add(new ArmorHudModule());
        add(new PotionHudModule());
        add(new KeystrokesModule());
        add(new CrosshairModule());
        // MOVEMENT
        add(new ToggleSprintModule());
        add(new ToggleSneakModule());
        add(new AutoJumpModule());
        add(new MovementHudModule());
        // CRYSTAL MACRO (hanya pintasan hotbar manual)
        add(new QuickSwapModule("Swap: End Crystal", "Pilih slot hotbar berisi End Crystal", 0, GLFW.GLFW_KEY_X));
        add(new QuickSwapModule("Swap: Obsidian", "Pilih slot hotbar berisi Obsidian", 1, Module.NO_KEY));
        add(new QuickSwapModule("Swap: Ender Pearl", "Pilih slot hotbar berisi Ender Pearl", 2, Module.NO_KEY));
        add(new QuickSwapModule("Swap: Totem", "Pilih slot hotbar berisi Totem of Undying", 3, Module.NO_KEY));
    }

    private static void add(Module m) { MODULES.add(m); }

    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }

    public static List<Module> of(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        throw new IllegalStateException("Modul tidak terdaftar: " + type.getSimpleName());
    }

    public static void tick() {
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try { m.onTick(); }
            catch (Throwable t) {
                ZoyyDarkClient.LOGGER.error("Modul {} dimatikan karena error di tick", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    public static void renderHud(GuiGraphics g, float pt) {
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            try { m.onHud(g, pt); }
            catch (Throwable t) {
                ZoyyDarkClient.LOGGER.error("Modul {} dimatikan karena error di render", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    public static void resetAll() {
        for (Module m : MODULES) m.resetAll();
        ClientSettings.resetAll();
    }
    private ModuleManager() {}
}
