package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;

/** Memory Usage Monitor (RAM JVM yang dipakai game). */
public class MemoryMonitorModule extends HudModule {
    public MemoryMonitorModule() { super("Memory Monitor", "Tampilkan pemakaian RAM", Category.PERFORMANCE, 100, 0); }

    @Override protected List<String> lines() {
        Runtime r = Runtime.getRuntime();
        long max = r.maxMemory() / 1048576L;
        long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
        return List.of("RAM: " + used + " / " + max + " MB (" + (max == 0 ? 0 : used * 100 / max) + "%)");
    }
}
