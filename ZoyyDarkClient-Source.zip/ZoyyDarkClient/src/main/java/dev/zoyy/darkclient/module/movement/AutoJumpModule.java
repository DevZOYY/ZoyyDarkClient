package dev.zoyy.darkclient.module.movement;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;

/** Menyalakan opsi Auto-Jump bawaan Minecraft (naik blok 1 tanpa melompat manual). */
public class AutoJumpModule extends Module {
    private boolean old;
    public AutoJumpModule() { super("Auto Jump", "Aktifkan Auto-Jump bawaan", Category.MOVEMENT); }
    @Override public void onEnable() { old = mc.options.autoJump().get(); mc.options.autoJump().set(true); }
    @Override public void onDisable() { mc.options.autoJump().set(old); }
}
