package dev.zoyy.darkclient.module.combat;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import dev.zoyy.darkclient.setting.Setting;
import java.util.List;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Item Counter: hitung item tertentu di inventory. */
public class ItemCounterModule extends HudModule {
    public final Setting.Mode item = add(new Setting.Mode("Item", 0,
            "End Crystal", "Ender Pearl", "Totem", "Golden Apple", "Obsidian", "Arrow", "Held Item"));

    public ItemCounterModule() { super("Item Counter", "Hitung item di inventory", Category.COMBAT, 100, 40); }

    @Override protected List<String> lines() {
        Inventory inv = mc.player.getInventory();
        Item target = switch (item.get()) {
            case "End Crystal" -> Items.END_CRYSTAL;
            case "Ender Pearl" -> Items.ENDER_PEARL;
            case "Totem" -> Items.TOTEM_OF_UNDYING;
            case "Golden Apple" -> Items.GOLDEN_APPLE;
            case "Obsidian" -> Items.OBSIDIAN;
            case "Arrow" -> Items.ARROW;
            default -> mc.player.getMainHandItem().getItem();
        };
        int count = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.getItem() == target) count += s.getCount();
        }
        return List.of(new ItemStack(target).getHoverName().getString() + ": " + count);
    }
}
