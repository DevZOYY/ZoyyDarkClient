package dev.zoyy.darkclient.core;

import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.util.KeyNames;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Polling keyboard + mouse lewat GLFW; mendukung Toggle, Hold, dan deteksi konflik. */
public final class KeybindManager {
    private static boolean guiWasDown;

    public static boolean isDown(int code) {
        if (code < 0) return false;
        long window = Minecraft.getInstance().getWindow().handle();
        if (code >= KeyNames.MOUSE_BASE) {
            return GLFW.glfwGetMouseButton(window, code - KeyNames.MOUSE_BASE) == GLFW.GLFW_PRESS;
        }
        return GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getWindow() == null) return;
        boolean free = mc.screen == null;

        boolean down = isDown(ClientSettings.guiKey);
        if (free && down && !guiWasDown) GuiManager.open();
        guiWasDown = down;

        for (Module m : ModuleManager.all()) {
            if (m.key < 0) { m.keyWasDown = false; continue; }
            boolean d = free && isDown(m.key);
            if (m.actionOnly) {
                if (d && !m.keyWasDown) m.onTrigger();
            } else if (m.holdMode) {
                if (d != m.keyWasDown) m.setEnabled(d);
            } else if (d && !m.keyWasDown) {
                m.toggle();
            }
            m.keyWasDown = d;
        }
    }

    /** Nama pemilik keybind yang bentrok, atau null bila aman. */
    public static String findConflict(int code, Module self, boolean selfIsGui) {
        if (code < 0) return null;
        if (!selfIsGui && code == ClientSettings.guiKey) return "ClickGUI";
        for (Module m : ModuleManager.all()) if (m != self && m.key == code) return m.name;
        return null;
    }

    /** @return null jika berhasil, selain itu nama fitur yang bentrok. */
    public static String bind(Module m, int code) {
        String c = findConflict(code, m, false);
        if (c != null) return c;
        m.key = code;
        return null;
    }

    public static String bindGui(int code) {
        String c = findConflict(code, null, true);
        if (c != null) return c;
        ClientSettings.guiKey = code;
        return null;
    }
    private KeybindManager() {}
}
