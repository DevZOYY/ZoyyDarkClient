package dev.zoyy.darkclient.module;

import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import dev.zoyy.darkclient.util.RenderUtil;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Modul HUD teks: posisi, transparansi, dan warna bisa diatur. */
public abstract class HudModule extends Module {
    protected final Setting.Num posX;
    protected final Setting.Num posY;
    protected final Setting.Num opacity = add(new Setting.Num("Opacity", 10, 100, 5, 80));
    protected final Setting.Mode color = add(new Setting.Mode("Color", 0, Colors.NAMES));
    protected final Setting.Bool background = add(new Setting.Bool("Background", true));

    protected HudModule(String name, String description, Category category, int defX, int defY) {
        super(name, description, category);
        posX = add(new Setting.Num("Position X %", 0, 100, 1, defX));
        posY = add(new Setting.Num("Position Y %", 0, 100, 1, defY));
    }

    /** Baris teks yang ditampilkan; kosong/null = tidak menggambar apa pun. */
    protected abstract List<String> lines();

    @Override
    public void onHud(GuiGraphics g, float pt) {
        if (mc.player == null) return;
        List<String> l = lines();
        if (l == null || l.isEmpty()) return;
        Font f = mc.font;
        int w = 0;
        for (String s : l) w = Math.max(w, f.width(s));
        int pad = 4;
        int bw = w + pad * 2, bh = l.size() * 10 + pad * 2 - 1;
        int x = (int) ((g.guiWidth() - bw) * posX.get() / 100.0);
        int y = (int) ((g.guiHeight() - bh) * posY.get() / 100.0);
        int a = (int) (opacity.get() * 2.55);
        if (background.get()) RenderUtil.rrect(g, x, y, bw, bh, 3, Colors.argb(0x000000, (int) (a * 0.55)));
        int rgb = Colors.rgb(color.get());
        for (int i = 0; i < l.size(); i++) {
            g.drawString(f, l.get(i), x + pad, y + pad + i * 10, Colors.argb(rgb, Math.max(a, 26)));
        }
    }
}
