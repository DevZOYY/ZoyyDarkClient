package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;
import dev.zoyy.darkclient.util.Colors;
import net.minecraft.client.gui.GuiGraphics;

/** Custom Crosshair + editor (style, ukuran, gap, ketebalan, warna, transparansi). */
public class CrosshairModule extends Module {
    public final Setting.Mode style = add(new Setting.Mode("Style", 0, "Cross", "Dot", "Plus (Dot)", "Square"));
    public final Setting.Num size = add(new Setting.Num("Size", 1, 20, 1, 5));
    public final Setting.Num gap = add(new Setting.Num("Gap", 0, 10, 1, 2));
    public final Setting.Num thickness = add(new Setting.Num("Thickness", 1, 5, 1, 1));
    public final Setting.Mode color = add(new Setting.Mode("Color", 0, Colors.NAMES));
    public final Setting.Num opacity = add(new Setting.Num("Opacity", 10, 100, 5, 100));
    public final Setting.Bool outline = add(new Setting.Bool("Outline", true));

    public CrosshairModule() { super("Custom Crosshair", "Crosshair buatan sendiri", Category.VISUAL); }

    public void draw(GuiGraphics g) {
        int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
        int s = size.getInt(), gp = gap.getInt(), t = thickness.getInt();
        int c = Colors.argb(Colors.rgb(color.get()), (int) (opacity.get() * 2.55));
        int o = Colors.argb(0x000000, (int) (opacity.get() * 2.55 * 0.8));
        int lo = -(t / 2);
        switch (style.get()) {
            case "Dot" -> box(g, cx + lo, cy + lo, t + 1, t + 1, c, o);
            case "Square" -> {
                int r = s + gp;
                g.fill(cx - r, cy - r, cx + r + 1, cy - r + t, c);
                g.fill(cx - r, cy + r + 1 - t, cx + r + 1, cy + r + 1, c);
                g.fill(cx - r, cy - r, cx - r + t, cy + r + 1, c);
                g.fill(cx + r + 1 - t, cy - r, cx + r + 1, cy + r + 1, c);
            }
            default -> {
                box(g, cx + lo, cy - gp - s, t, s, c, o);        // atas
                box(g, cx + lo, cy + gp + 1, t, s, c, o);         // bawah
                box(g, cx - gp - s, cy + lo, s, t, c, o);         // kiri
                box(g, cx + gp + 1, cy + lo, s, t, c, o);         // kanan
                if (style.get().equals("Plus (Dot)")) box(g, cx + lo, cy + lo, t, t, c, o);
            }
        }
    }

    private void box(GuiGraphics g, int x, int y, int w, int h, int c, int o) {
        if (outline.get()) g.fill(x - 1, y - 1, x + w + 1, y + h + 1, o);
        g.fill(x, y, x + w, y + h, c);
    }
}
