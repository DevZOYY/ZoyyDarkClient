package dev.zoyy.darkclient;

import dev.zoyy.darkclient.core.ConfigManager;
import dev.zoyy.darkclient.core.EventManager;
import dev.zoyy.darkclient.core.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZoyyDarkClient implements ClientModInitializer {
    public static final String MOD_ID = "zoyydarkclient";
    public static final String NAME = "ZoyyDarkClient";
    public static final String VERSION = "1.0.0";
    public static final String MC_VERSION = "1.21.11";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();
        EventManager.init();
        LOGGER.info("{} {} dimuat ({} modul)", NAME, VERSION, ModuleManager.all().size());
    }
}
