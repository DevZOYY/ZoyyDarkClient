package dev.zoyy.darkclient.core;

import dev.zoyy.darkclient.ZoyyDarkClient;
import dev.zoyy.darkclient.module.visual.CrosshairModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/** Pusat pendaftaran event Fabric. Semua modul dipanggil dari sini. */
public final class EventManager {
    private static int saveTimer;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            try {
                KeybindManager.tick();
                ModuleManager.tick();
                if (++saveTimer >= 6000) { saveTimer = 0; ConfigManager.save(); } // autosave ~5 menit
            } catch (Throwable t) {
                ZoyyDarkClient.LOGGER.error("Error di tick", t);
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ConfigManager.save());

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(ZoyyDarkClient.MOD_ID, "hud"),
                (graphics, deltaTracker) -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player == null || mc.options.hideGui) return;
                    ModuleManager.renderHud(graphics, deltaTracker.getGameTimeDeltaPartialTick(false));
                });

        // Crosshair custom menggantikan bawaan hanya saat modul aktif.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, deltaTracker) -> {
            CrosshairModule c = ModuleManager.get(CrosshairModule.class);
            if (c.isEnabled()) c.draw(graphics); else original.render(graphics, deltaTracker);
        });
    }
    private EventManager() {}
}
