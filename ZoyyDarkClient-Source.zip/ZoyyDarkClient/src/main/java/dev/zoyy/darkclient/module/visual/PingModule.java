package dev.zoyy.darkclient.module.visual;

import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.HudModule;
import java.util.List;
import net.minecraft.client.multiplayer.PlayerInfo;

public class PingModule extends HudModule {
    public PingModule() { super("Ping Display", "Tampilkan ping server", Category.VISUAL, 0, 18); }
    @Override protected List<String> lines() {
        if (mc.getConnection() == null) return null;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        if (info == null) return null;
        return List.of(mc.hasSingleplayerServer() ? "Ping: Local" : "Ping: " + info.getLatency() + " ms");
    }
}
