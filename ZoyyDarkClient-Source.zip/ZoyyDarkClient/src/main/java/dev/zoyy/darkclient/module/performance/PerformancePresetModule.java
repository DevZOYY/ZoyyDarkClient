package dev.zoyy.darkclient.module.performance;

import dev.zoyy.darkclient.core.ModuleManager;
import dev.zoyy.darkclient.module.Category;
import dev.zoyy.darkclient.module.Module;
import dev.zoyy.darkclient.setting.Setting;

/**
 * Preset Potato..Extreme. Mengatur dan mengaktifkan modul performance lain.
 * "Custom" tidak mengubah apa pun. Mode Extreme = render/entity/partikel paling hemat
 * + Dynamic Render Distance + Dynamic FPS.
 */
public class PerformancePresetModule extends Module {
    public final Setting.Mode preset = add(new Setting.Mode("Preset", 2, "Potato", "Low", "Balanced", "High", "Extreme", "Custom"));

    public PerformancePresetModule() {
        super("Performance Preset", "Potato / Low / Balanced / High / Extreme / Custom", Category.PERFORMANCE);
        preset.onChange = () -> { if (isEnabled()) apply(); };
    }

    @Override public void onEnable() { apply(); }

    private void apply() {
        String p = preset.get();
        if (p.equals("Custom")) return;
        RenderDistanceModule rd = ModuleManager.get(RenderDistanceModule.class);
        EntityDistanceModule ed = ModuleManager.get(EntityDistanceModule.class);
        ParticleLimiterModule pl = ModuleManager.get(ParticleLimiterModule.class);
        DynamicFpsModule df = ModuleManager.get(DynamicFpsModule.class);
        switch (p) {
            case "Potato" -> set(rd, 4, 5, false, ed, 50, pl, "Minimal", df, true);
            case "Low" -> set(rd, 6, 6, false, ed, 60, pl, "Decreased", df, true);
            case "Balanced" -> set(rd, 10, 8, false, ed, 100, pl, "Decreased", df, false);
            case "High" -> set(rd, 16, 12, false, ed, 150, pl, "All", df, false);
            case "Extreme" -> set(rd, 8, 6, true, ed, 60, pl, "Minimal", df, true);
            default -> { }
        }
    }

    private void set(RenderDistanceModule rd, int render, int sim, boolean dyn, EntityDistanceModule ed, int ent,
                     ParticleLimiterModule pl, String particles, DynamicFpsModule df, boolean dynFps) {
        rd.render.set(render); rd.simulation.set(sim); rd.dynamic.set(dyn);
        rd.setEnabled(false); rd.setEnabled(true);          // terapkan ulang nilai baru
        ed.percent.set(ent); ed.setEnabled(false); ed.setEnabled(true);
        pl.level.set(pl.level.modes.indexOf(particles)); pl.setEnabled(false); pl.setEnabled(true);
        df.setEnabled(dynFps);
    }
}
