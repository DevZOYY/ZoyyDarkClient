# Build

Butuh: JDK 21. Versi (lihat `gradle.properties`): Minecraft 1.21.11, Loader 0.18.4, Fabric API 0.141.3+1.21.11,
Loom 1.14-SNAPSHOT, Gradle 9.2.1. Cek versi terbaru di https://fabricmc.net/develop jika perlu.

## Opsi A: GitHub Actions (tanpa install apa pun)
1. Buat repo GitHub, upload isi folder source (termasuk `.github/workflows/build.yml`).
2. Tab **Actions** -> workflow "Build ZoyyDarkClient" -> tunggu selesai.
3. Unduh artifact `ZoyyDarkClient-1.21.11` (berisi JAR). Kalau gagal, buka log: error kompilasi akan tampil.

## Opsi B: Lokal
```
gradle wrapper --gradle-version 9.2.1   # sekali saja (butuh Gradle terpasang)
./gradlew build                          # Windows: gradlew.bat build
```
Hasil: `build/libs/ZoyyDarkClient-1.21.11.jar` (jangan pakai file `-sources`).
Uji: `./gradlew runClient`.

## Titik yang paling mungkin perlu penyesuaian (API berubah di 1.21.9-1.21.11)
- `Minecraft.getWindow().handle()` (handle GLFW) di `KeybindManager` dan `ClickGuiScreen`.
- `MouseButtonEvent` / `KeyEvent` di `ClickGuiScreen` (signature `mouseClicked`, `keyPressed`).
- `GuiGraphics.blit(RenderPipelines.GUI_TEXTURED, ...)` (12 argumen) di `ClickGuiScreen`.
- `HudElementRegistry` / `VanillaHudElements` di `EventManager`.
- `Inventory.getSelectedSlot()/setSelectedSlot()` di `QuickSwapModule`.
- `Minecraft.getFps()` di beberapa modul HUD.
