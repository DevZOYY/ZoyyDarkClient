# ZoyyDarkClient (Fabric 1.21.11)

Client mod Minecraft Java **1.21.11** (Fabric, Official Mojang Mappings) dengan ClickGUI dark monochrome.
Mod ID: `zoyydarkclient` · Developer: Zoyy Team

> **Status jujur:** source ini ditulis tanpa akses internet, jadi **belum pernah dikompilasi atau dijalankan**.
> API 1.21.11 berubah cukup banyak (input, rendering GUI). Kalau build error, kirim pesan error-nya, biasanya cuma
> beda nama method. Lihat BUILD.md.

## Instalasi
1. Pasang Fabric Loader (>= 0.18.0) untuk Minecraft 1.21.11 + **Fabric API**.
2. Taruh `ZoyyDarkClient-1.21.11.jar` (hasil build) di folder `mods`.
3. Masuk ke dunia, tekan **Right Shift** untuk membuka ClickGUI (bisa diganti di Settings).

## Isi (semua tombol terhubung ke fungsi nyata)
- **ClickGUI**: background anime (gambar mentah + dim gelap), avatar bulat, sidebar kategori, toggle, slider, dropdown,
  Save Configuration, Reset Settings, animasi buka/tutup.
- **Keybind**: editor di tiap fitur + Keybind Manager di Settings, deteksi konflik, reset default, mode Toggle/Hold,
  mendukung tombol mouse. Backspace/Delete saat mendengarkan = hapus keybind.
- **Performance** (lewat opsi resmi Minecraft, aman): Performance Preset (Potato/Low/Balanced/High/Extreme/Custom),
  FPS Limiter + VSync, Render/Simulation Distance + Dynamic Render Distance, Entity Distance, Particle Limiter,
  Dynamic FPS (saat tidak fokus), Memory Monitor.
- **Combat** (informasi saja): CPS Counter, Target HUD, Item Counter.
- **Visual**: FPS, Coordinates, Ping, Direction, Health, Armor HUD, Potion HUD, Keystrokes, Custom Crosshair
  (warna, ukuran, gap, ketebalan, opacity, outline). HUD teks punya posisi X/Y, opacity, warna.
- **Movement**: Toggle Sprint, Toggle Sneak, Auto Jump, Movement HUD (speed + statistik).
- **Crystal Macro**: pintasan hotbar manual (End Crystal / Obsidian / Ender Pearl / Totem). Hanya memilih slot.
- **Settings**: animasi, dim background, tema, warna aksen, sound, Keybind Manager, Export/Import config, Reset All.
- **About**: versi, loader, developer, FPS, memori, status.

Config tersimpan otomatis (saat GUI ditutup, tiap ±5 menit, dan saat game keluar) di `config/zoyydarkclient.json`.

## Sengaja TIDAK dibuat
Auto Attack, Auto Counter Hit, Auto Pearl, Auto Mace, perbesar Hitbox/Reach, dan auto-place Crystal. Itu cheat PvP
yang memberi keuntungan tidak adil dan bisa membuat akun kena ban. Entity/chunk culling dan optimasi render
mendalam butuh mixin; untuk itu pakai Sodium/Lithium berdampingan dengan mod ini.
